-- Vaani Transcribe — database schema
-- Run this in the Supabase SQL editor (or via `supabase db push`).
-- Auth users live in the built-in `auth.users` table; we don't duplicate them.

create extension if not exists "uuid-ossp";

-- ────────────────────────────────────────────────────────────
-- transcriptions
-- ────────────────────────────────────────────────────────────
create table if not exists public.transcriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade,
  filename text,
  source_url text,
  language text,
  language_label text,
  confidence numeric,
  duration numeric not null default 0,
  transcript text,
  transcript_segments jsonb,
  status text not null default 'processing'
    check (status in ('uploading','processing_audio','detecting_language','transcribing','preparing_transcript','complete','error')),
  error_message text,
  storage_path text,          -- path in Supabase Storage, if the media was retained
  media_retained boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists transcriptions_user_id_idx on public.transcriptions(user_id);
create index if not exists transcriptions_created_at_idx on public.transcriptions(created_at desc);

alter table public.transcriptions enable row level security;

-- Users can only ever see and modify their own rows.
create policy "transcriptions_select_own"
  on public.transcriptions for select
  using (auth.uid() = user_id);

create policy "transcriptions_insert_own"
  on public.transcriptions for insert
  with check (auth.uid() = user_id);

create policy "transcriptions_update_own"
  on public.transcriptions for update
  using (auth.uid() = user_id);

create policy "transcriptions_delete_own"
  on public.transcriptions for delete
  using (auth.uid() = user_id);

-- ────────────────────────────────────────────────────────────
-- usage — one row per user per billing period
-- ────────────────────────────────────────────────────────────
create table if not exists public.usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  billing_period text not null, -- e.g. '2026-09'
  transcription_count integer not null default 0,
  total_audio_seconds numeric not null default 0,
  updated_at timestamptz not null default now(),
  primary key (user_id, billing_period)
);

alter table public.usage enable row level security;

create policy "usage_select_own"
  on public.usage for select
  using (auth.uid() = user_id);

-- Usage rows are written by server-side code using the service role key,
-- which bypasses RLS — regular users never get insert/update access directly.

-- ────────────────────────────────────────────────────────────
-- Keep updated_at fresh
-- ────────────────────────────────────────────────────────────
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists transcriptions_set_updated_at on public.transcriptions;
create trigger transcriptions_set_updated_at
  before update on public.transcriptions
  for each row execute procedure public.set_updated_at();

-- ────────────────────────────────────────────────────────────
-- Storage bucket for uploaded media (created here for reference —
-- buckets are usually created once via the Supabase dashboard/CLI)
-- ────────────────────────────────────────────────────────────
insert into storage.buckets (id, name, public)
values ('media-uploads', 'media-uploads', false)
on conflict (id) do nothing;

create policy "media_uploads_owner_read"
  on storage.objects for select
  using (bucket_id = 'media-uploads' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "media_uploads_owner_write"
  on storage.objects for insert
  with check (bucket_id = 'media-uploads' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "media_uploads_owner_delete"
  on storage.objects for delete
  using (bucket_id = 'media-uploads' and auth.uid()::text = (storage.foldername(name))[1]);
