"use client";

import { useState } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

// Needs real Supabase env vars to create a client, so it can't be statically
// prerendered without them at build time — render on request instead.
export const dynamic = "force-dynamic";

export default function LoginPage() {
  const supabase = createSupabaseBrowserClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleGoogle() {
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/dashboard` },
    });
  }

  async function handleEmailAuth(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    const { error } =
      mode === "signin"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password });
    setBusy(false);
    if (error) {
      setMessage(error.message);
      return;
    }
    if (mode === "signup") {
      setMessage("Check your inbox to confirm your email.");
    } else {
      window.location.href = "/dashboard";
    }
  }

  async function handleReset() {
    if (!email) {
      setMessage("Enter your email above first.");
      return;
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/login`,
    });
    setMessage(error ? error.message : "Password reset email sent.");
  }

  return (
    <main className="max-w-sm mx-auto px-6 py-20">
      <h1 className="font-display text-2xl mb-6">{mode === "signin" ? "Log in" : "Sign up"}</h1>

      <button
        onClick={handleGoogle}
        className="w-full mb-4 px-4 py-2.5 rounded-lg border border-border bg-surface text-sm"
      >
        Continue with Google
      </button>

      <div className="text-center text-xs text-muted mb-4">or</div>

      <form onSubmit={handleEmailAuth} className="space-y-3">
        <input
          type="email"
          required
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-surface2 border border-border rounded-lg px-3 py-2.5 text-sm"
        />
        <input
          type="password"
          required
          minLength={6}
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full bg-surface2 border border-border rounded-lg px-3 py-2.5 text-sm"
        />
        <button
          type="submit"
          disabled={busy}
          className="w-full px-4 py-2.5 rounded-lg bg-accent text-white text-sm font-medium disabled:opacity-50"
        >
          {mode === "signin" ? "Log in" : "Create account"}
        </button>
      </form>

      <div className="flex justify-between mt-4 text-xs text-muted">
        <button onClick={() => setMode(mode === "signin" ? "signup" : "signin")}>
          {mode === "signin" ? "Need an account? Sign up" : "Have an account? Log in"}
        </button>
        <button onClick={handleReset}>Forgot password?</button>
      </div>

      {message && <p className="text-sm text-accent2 mt-4">{message}</p>}
    </main>
  );
}
