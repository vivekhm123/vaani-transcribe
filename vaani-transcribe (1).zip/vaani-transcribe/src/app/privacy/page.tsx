export const metadata = { title: "Privacy Policy — Vaani" };

export default function PrivacyPage() {
  return (
    <main className="max-w-2xl mx-auto px-6 py-16 prose-invert">
      <h1 className="font-display text-3xl mb-6">Privacy Policy</h1>
      <div className="space-y-6 text-sm text-muted leading-relaxed">
        <section>
          <h2 className="text-white font-medium mb-2">What we collect</h2>
          <p>
            When you use the transcription tool, we process the video or audio file you upload (or
            the file at the URL you provide) in order to generate a transcript. If you're signed in,
            we store the resulting text, timestamps, detected language and confidence score against
            your account. We do not require or collect more account information than an email
            address and, optionally, a name from your Google account.
          </p>
        </section>
        <section>
          <h2 className="text-white font-medium mb-2">How your file is processed</h2>
          <p>
            Your file is sent securely to our speech-to-text provider for processing. We don't use
            uploaded media to train any model. Processing happens server-side; the provider's API
            key is never exposed to your browser.
          </p>
        </section>
        <section>
          <h2 className="text-white font-medium mb-2">How long files are stored</h2>
          <p>
            By default, the original media file is <strong>not retained</strong> after transcription
            completes — it exists only in server memory for the duration of processing and is
            discarded once the transcript is returned. Only the text transcript and its timestamps
            are saved to your account. If a future version of the app adds an explicit "save the
            original file" option, that will be opt-in and disclosed at the time.
          </p>
        </section>
        <section>
          <h2 className="text-white font-medium mb-2">Deleting your data</h2>
          <p>
            You can delete any individual transcript from your dashboard, which permanently removes
            the transcript text and timestamps from our database. Deleting your account removes all
            associated transcripts and usage records.
          </p>
        </section>
        <section>
          <h2 className="text-white font-medium mb-2">Third parties</h2>
          <p>
            We use Supabase for authentication, database and (if enabled) file storage, and an
            OpenAI-compatible provider for speech-to-text and translation. Each processes data only
            as needed to perform the request you initiated.
          </p>
        </section>
        <section>
          <h2 className="text-white font-medium mb-2">Contact</h2>
          <p>Questions about this policy or a data deletion request: hello@example.com</p>
        </section>
      </div>
    </main>
  );
}
