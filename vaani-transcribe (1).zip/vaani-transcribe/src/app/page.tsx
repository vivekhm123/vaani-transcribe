import TranscribeTool from "@/components/TranscribeTool";
import Faq, { FAQS } from "@/components/Faq";
import { SUPPORTED_LANGUAGES } from "@/lib/config/limits";

const HOW_IT_WORKS = [
  { t: "Upload or paste a link", d: "Drop in a video/audio file, or a direct link to one." },
  { t: "AI transcribes", d: "Speech is converted to timestamped text and the spoken language is detected automatically." },
  { t: "Edit, translate, export", d: "Fix any line, romanize it, translate it, then download TXT, SRT or VTT." },
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQS.map((f) => ({
    "@type": "Question",
    name: f.q,
    acceptedAnswer: { "@type": "Answer", text: f.a },
  })),
};

const appSchema = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: "Vaani",
  applicationCategory: "MultimediaApplication",
  operatingSystem: "Any (web-based)",
  offers: { "@type": "Offer", price: "0", priceCurrency: "INR" },
  description:
    "AI video and audio transcription for Indian languages, with romanization, translation and SRT/VTT export.",
};

export default function Home() {
  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(appSchema) }} />

      <nav className="border-b border-border">
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <span className="font-display text-lg">Vaani</span>
          <div className="flex gap-3 text-sm">
            <a href="/login" className="text-muted">Log in</a>
            <a href="/login" className="px-4 py-2 rounded-lg bg-accent text-white">Try free</a>
          </div>
        </div>
      </nav>

      <section className="max-w-3xl mx-auto px-6 pt-16 pb-10 text-center">
        <h1 className="font-display text-4xl md:text-5xl leading-tight mb-4">
          AI Video Transcription Tool
        </h1>
        <p className="text-muted text-lg max-w-2xl mx-auto">
          Convert video and audio into accurate text in Hindi, Kannada, Tamil, Telugu, Malayalam,
          Marathi, Bengali, Gujarati, Punjabi, English and more.
        </p>
      </section>

      <section className="max-w-3xl mx-auto px-6 pb-16">
        <TranscribeTool />
      </section>

      <section id="how" className="max-w-4xl mx-auto px-6 py-14 border-t border-border">
        <h2 className="font-display text-2xl mb-8">How it works</h2>
        <div className="grid md:grid-cols-3 gap-5">
          {HOW_IT_WORKS.map((s, i) => (
            <div key={s.t} className="rounded-xl border border-border bg-surface p-5">
              <div className="font-display text-2xl text-accent mb-2">{i + 1}</div>
              <div className="font-medium mb-1">{s.t}</div>
              <div className="text-sm text-muted">{s.d}</div>
            </div>
          ))}
        </div>
      </section>

      <section id="languages" className="max-w-4xl mx-auto px-6 py-14 border-t border-border">
        <h2 className="font-display text-2xl mb-2">Supported languages</h2>
        <p className="text-muted text-sm mb-8">
          Auto-detected, including sentences that mix two languages together.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {SUPPORTED_LANGUAGES.map((l) => (
            <div key={l.code} className="rounded-lg border border-border bg-surface p-4">
              <div className="font-display text-lg">{l.native}</div>
              <div className="text-xs text-muted">{l.name}</div>
            </div>
          ))}
        </div>
      </section>

      <Faq />

      <footer className="border-t border-border">
        <div className="max-w-5xl mx-auto px-6 py-8 flex flex-wrap justify-between gap-4 text-sm text-muted">
          <span>© {new Date().getFullYear()} Vaani</span>
          <div className="flex gap-5">
            <a href="/privacy">Privacy</a>
            <a href="/terms">Terms</a>
            <a href="mailto:hello@example.com">Contact</a>
          </div>
        </div>
      </footer>
    </main>
  );
}
