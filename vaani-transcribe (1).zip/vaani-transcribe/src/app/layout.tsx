import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vaani — AI Video Transcription Tool for Indian Languages",
  description:
    "Convert video and audio into accurate, editable text in Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi, Bengali, Gujarati, Punjabi, English and more. Supports mixed-language speech.",
  metadataBase: new URL("https://example.com"),
  openGraph: {
    title: "Vaani — AI Video Transcription Tool for Indian Languages",
    description:
      "Upload a video or audio file and get an accurate, editable, multilingual transcript with subtitle export.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Vaani — AI Video Transcription Tool for Indian Languages",
    description: "Multilingual video-to-text for Indian languages, with SRT/VTT export.",
  },
  alternates: { canonical: "/" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans">{children}</body>
    </html>
  );
}
