import { NextRequest, NextResponse } from "next/server";
import { ApiError } from "@/types";
import { transcriptionService } from "@/lib/transcription/service";

export async function POST(req: NextRequest) {
  try {
    const { segments, targetLanguageName } = await req.json();
    if (!Array.isArray(segments) || !targetLanguageName) {
      throw new ApiError("INVALID_URL", "Missing segments or target language.", 400);
    }
    const translated = await transcriptionService.translateTranscript(segments, targetLanguageName);
    return NextResponse.json({ segments: translated });
  } catch (err) {
    if (err instanceof ApiError) {
      return NextResponse.json({ code: err.code, message: err.message }, { status: err.status });
    }
    console.error("Unhandled /api/translate error:", err);
    return NextResponse.json(
      { code: "PROVIDER_FAILURE", message: "Translation failed. Please try again." },
      { status: 500 }
    );
  }
}
