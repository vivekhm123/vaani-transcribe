import { NextRequest, NextResponse } from "next/server";
import { ApiError } from "@/types";
import { transcriptionService } from "@/lib/transcription/service";

export async function POST(req: NextRequest) {
  try {
    const { segments } = await req.json();
    if (!Array.isArray(segments)) {
      throw new ApiError("INVALID_URL", "Missing segments.", 400);
    }
    const romanized = await transcriptionService.romanizeTranscript(segments);
    return NextResponse.json({ segments: romanized });
  } catch (err) {
    if (err instanceof ApiError) {
      return NextResponse.json({ code: err.code, message: err.message }, { status: err.status });
    }
    console.error("Unhandled /api/romanize error:", err);
    return NextResponse.json(
      { code: "PROVIDER_FAILURE", message: "Romanization failed. Please try again." },
      { status: 500 }
    );
  }
}
