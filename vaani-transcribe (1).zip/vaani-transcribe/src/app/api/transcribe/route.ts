import { NextRequest, NextResponse } from "next/server";
import { ApiError } from "@/types";
import { ACCEPTED_EXTENSIONS, ACCEPTED_MIME_TYPES, LIMITS } from "@/lib/config/limits";
import { transcriptionService } from "@/lib/transcription/service";
import { enforceUsageLimits } from "@/lib/usage";
import { createSupabaseServerClient, createSupabaseServiceClient } from "@/lib/supabase/server";

export const runtime = "nodejs";
export const maxDuration = 300; // seconds — long enough for large files; tune per hosting provider

function extensionOf(name: string) {
  const i = name.lastIndexOf(".");
  return i === -1 ? "" : name.slice(i).toLowerCase();
}

export async function POST(req: NextRequest) {
  try {
    const supabase = createSupabaseServerClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    const contentType = req.headers.get("content-type") || "";

    // ── Path A: file upload (multipart/form-data) ─────────────────────────
    if (contentType.includes("multipart/form-data")) {
      const form = await req.formData();
      const file = form.get("file") as File | null;
      const anonymousId = (form.get("anonymousId") as string) || "unknown";

      if (!file) {
        throw new ApiError("UNSUPPORTED_FORMAT", "No file was received.", 400);
      }

      const ext = extensionOf(file.name);
      if (!ACCEPTED_EXTENSIONS.includes(ext) && !ACCEPTED_MIME_TYPES.includes(file.type as any)) {
        throw new ApiError("UNSUPPORTED_FORMAT", "Unsupported file format.", 400);
      }
      if (file.size > LIMITS.maxUploadBytes) {
        throw new ApiError(
          "FILE_TOO_LARGE",
          "Your file exceeds the maximum allowed size.",
          413
        );
      }

      // We don't know exact duration until the provider processes the file;
      // usage limits are re-checked with the real duration after transcription
      // completes, but we do a coarse pre-check here to fail fast on obviously
      // oversized anonymous requests.
      const usage = await enforceUsageLimits({
        userId: user?.id ?? null,
        anonymousId,
        estimatedDurationSeconds: 0,
      });

      const result = await transcriptionService.transcribeAudio(file, file.name);

      if (result.durationSeconds > LIMITS.free.maxDurationSeconds && !user) {
        throw new ApiError(
          "LIMIT_REACHED",
          `This file is longer than the ${Math.round(LIMITS.anonymous.maxDurationSeconds / 60)}-minute anonymous limit. Sign up to transcribe longer files.`,
          413
        );
      }

      await usage.recordUsage(result.durationSeconds);

      let savedId: string | null = null;
      if (user) {
        const service = createSupabaseServiceClient();
        const { data } = await service
          .from("transcriptions")
          .insert({
            user_id: user.id,
            filename: file.name,
            language: result.language,
            language_label: result.languageLabel,
            confidence: result.confidence,
            duration: result.durationSeconds,
            transcript: result.segments.map((s) => s.text).join(" "),
            transcript_segments: result.segments,
            status: "complete",
          })
          .select("id")
          .single();
        savedId = data?.id ?? null;
      }

      return NextResponse.json({ id: savedId, ...result });
    }

    // ── Path B: direct-file URL ────────────────────────────────────────────
    const body = await req.json().catch(() => null);
    const url: string | undefined = body?.url;

    if (!url) {
      throw new ApiError("INVALID_URL", "Please enter a valid supported URL.", 400);
    }

    let parsed: URL;
    try {
      parsed = new URL(url);
    } catch {
      throw new ApiError("INVALID_URL", "Please enter a valid supported URL.", 400);
    }

    const ext = extensionOf(parsed.pathname);
    // We only fetch URLs that point directly at a supported media file we can
    // stream server-side. We deliberately do not attempt to scrape or bypass
    // auth/rate limits on platforms like Instagram/YouTube — see README §URL processing.
    if (!ACCEPTED_EXTENSIONS.includes(ext)) {
      return NextResponse.json(
        {
          code: "URL_UNAVAILABLE",
          message: "URL transcription is currently unavailable. Upload your video or audio file instead.",
        },
        { status: 501 }
      );
    }

    let mediaRes: Response;
    try {
      mediaRes = await fetch(parsed.toString());
      if (!mediaRes.ok) throw new Error("fetch failed");
    } catch {
      throw new ApiError(
        "URL_UNAVAILABLE",
        "We couldn't access this media. Please upload the file instead.",
        502
      );
    }

    const blob = await mediaRes.blob();
    if (blob.size > LIMITS.maxUploadBytes) {
      throw new ApiError("FILE_TOO_LARGE", "Your file exceeds the maximum allowed size.", 413);
    }

    const usage = await enforceUsageLimits({
      userId: user?.id ?? null,
      anonymousId: "url-request",
      estimatedDurationSeconds: 0,
    });

    const filename = parsed.pathname.split("/").pop() || "media";
    const result = await transcriptionService.transcribeAudio(blob, filename);
    await usage.recordUsage(result.durationSeconds);

    let savedId: string | null = null;
    if (user) {
      const service = createSupabaseServiceClient();
      const { data } = await service
        .from("transcriptions")
        .insert({
          user_id: user.id,
          source_url: url,
          language: result.language,
          language_label: result.languageLabel,
          confidence: result.confidence,
          duration: result.durationSeconds,
          transcript: result.segments.map((s) => s.text).join(" "),
          transcript_segments: result.segments,
          status: "complete",
        })
        .select("id")
        .single();
      savedId = data?.id ?? null;
    }

    return NextResponse.json({ id: savedId, ...result });
  } catch (err) {
    if (err instanceof ApiError) {
      return NextResponse.json({ code: err.code, message: err.message }, { status: err.status });
    }
    console.error("Unhandled /api/transcribe error:", err);
    return NextResponse.json(
      { code: "PROVIDER_FAILURE", message: "Transcription failed. Please try again." },
      { status: 500 }
    );
  }
}
