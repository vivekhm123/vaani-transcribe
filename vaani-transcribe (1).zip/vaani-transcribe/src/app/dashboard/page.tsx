import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { LIMITS } from "@/lib/config/limits";

export default async function DashboardPage() {
  const supabase = createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: transcriptions } = await supabase
    .from("transcriptions")
    .select("id, filename, source_url, language_label, duration, status, created_at")
    .order("created_at", { ascending: false })
    .limit(20);

  const period = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, "0")}`;
  const { data: usage } = await supabase
    .from("usage")
    .select("transcription_count")
    .eq("user_id", user.id)
    .eq("billing_period", period)
    .maybeSingle();

  const used = usage?.transcription_count ?? 0;

  return (
    <main className="max-w-4xl mx-auto px-6 py-12">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="font-display text-2xl">Welcome back</h1>
          <p className="text-muted text-sm">{user.email}</p>
        </div>
        <a href="/" className="px-4 py-2 rounded-lg bg-accent text-white text-sm">+ New transcription</a>
      </div>

      <div className="rounded-xl border border-border bg-surface p-5 mb-8 max-w-sm">
        <div className="text-xs text-muted mb-1">Transcriptions used this month</div>
        <div className="font-display text-xl mb-3">
          {used} / {LIMITS.free.monthlyTranscriptions}
        </div>
        <div className="h-1.5 rounded-full bg-surface2 overflow-hidden">
          <div
            className="h-full bg-accent"
            style={{ width: `${Math.min(100, (used / LIMITS.free.monthlyTranscriptions) * 100)}%` }}
          />
        </div>
      </div>

      <div className="rounded-xl border border-border bg-surface p-5">
        <h2 className="font-medium mb-4">Recent transcriptions</h2>
        {!transcriptions || transcriptions.length === 0 ? (
          <p className="text-sm text-muted">No transcriptions yet — upload your first file from the home page.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted border-b border-border">
                <th className="pb-2">File / source</th>
                <th className="pb-2">Language</th>
                <th className="pb-2">Duration</th>
                <th className="pb-2">Date</th>
                <th className="pb-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {transcriptions.map((t: any) => (
                <tr key={t.id} className="border-b border-border last:border-0">
                  <td className="py-3">{t.filename || t.source_url || "—"}</td>
                  <td className="py-3">{t.language_label || "—"}</td>
                  <td className="py-3">{Math.round(t.duration || 0)}s</td>
                  <td className="py-3">{new Date(t.created_at).toLocaleDateString()}</td>
                  <td className="py-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-accent2/10 text-accent2">{t.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </main>
  );
}
