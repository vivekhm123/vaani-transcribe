export type TranscriptSegment = {
  id: string;
  start: number; // seconds
  end: number; // seconds
  text: string;
};

export type TranscriptionResult = {
  language: string; // ISO-ish code as reported by the provider, e.g. "kn"
  languageLabel: string; // human readable, e.g. "Kannada"
  confidence: number; // 0-1
  durationSeconds: number;
  segments: TranscriptSegment[];
};

export type TranscriptionStatus =
  | "uploading"
  | "processing_audio"
  | "detecting_language"
  | "transcribing"
  | "preparing_transcript"
  | "complete"
  | "error";

export type TranscriptionRow = {
  id: string;
  user_id: string | null;
  filename: string | null;
  source_url: string | null;
  language: string | null;
  duration: number | null;
  transcript: string | null;
  transcript_segments: TranscriptSegment[] | null;
  status: TranscriptionStatus;
  created_at: string;
};

export type ApiErrorCode =
  | "UNSUPPORTED_FORMAT"
  | "FILE_TOO_LARGE"
  | "INVALID_URL"
  | "URL_UNAVAILABLE"
  | "NO_SPEECH_DETECTED"
  | "UNSUPPORTED_LANGUAGE"
  | "PROVIDER_NOT_CONFIGURED"
  | "PROVIDER_FAILURE"
  | "TIMEOUT"
  | "LIMIT_REACHED"
  | "UNAUTHORIZED";

export class ApiError extends Error {
  code: ApiErrorCode;
  status: number;
  constructor(code: ApiErrorCode, message: string, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}
