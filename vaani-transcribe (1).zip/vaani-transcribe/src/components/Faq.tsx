const FAQS = [
  {
    q: "How accurate is transcription for Indian languages?",
    a: "Accuracy depends on audio clarity and how much the speech mixes languages, but modern speech-to-text models handle Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi, Bengali, Gujarati, Punjabi and Odia well for typical speech. Background noise, overlapping speakers and heavy code-switching within a single sentence lower accuracy — always review the transcript before publishing subtitles.",
  },
  {
    q: "Can it transcribe a mix of English and an Indian language in the same recording?",
    a: "Yes. The model is not forced to pick a single language, so a sentence like \"Guys, ivattu naavu one very important topic bagge maatadona\" keeps its original mix of English and Kannada instead of being flattened into one language.",
  },
  {
    q: "What's the difference between the Original, Romanized and Translation tabs?",
    a: "Original is the transcript exactly as spoken, in its native script. Romanized converts that script into casual Roman/Latin spelling — the way a creator would type it in a comment. Translation moves the meaning into a different language entirely, generated on demand for whichever language you pick.",
  },
  {
    q: "Can I edit the transcript before exporting it?",
    a: "Yes — every segment is an editable text field. Fix a misheard word or split a line, then export; your edits are included in the TXT, SRT and VTT downloads.",
  },
  {
    q: "Is the SRT file real subtitle timing, or just the text renamed?",
    a: "It's generated from the actual segment start/end timestamps returned by the speech-to-text model, in standard SRT numbering and HH:MM:SS,mmm format — it will load correctly in a video editor or player.",
  },
  {
    q: "What happens to my uploaded file after transcription?",
    a: "By default the media itself isn't kept — only the resulting text and timestamps are stored against your account. See the Privacy Policy for the exact retention rule and how to delete a transcript.",
  },
  {
    q: "Is there a limit on file length?",
    a: "Free accounts can transcribe files up to 5 minutes long, a limited number of times per month; paid plans raise both limits. Anonymous (not signed in) use is capped lower — sign up for the free tier's full allowance.",
  },
];

export default function Faq() {
  return (
    <section id="faq" className="max-w-3xl mx-auto px-6 py-16">
      <h2 className="font-display text-2xl mb-8">Frequently asked questions</h2>
      <div className="space-y-6">
        {FAQS.map((f) => (
          <div key={f.q} className="border-b border-border pb-6">
            <h3 className="font-medium mb-2">{f.q}</h3>
            <p className="text-sm text-muted leading-relaxed">{f.a}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export { FAQS };
