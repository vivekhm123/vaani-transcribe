"use client";

import { useRef, useState } from "react";
import { v4 as uuid } from "uuid";
import { ACCEPTED_EXTENSIONS } from "@/lib/config/limits";
import type { TranscriptionResult } from "@/types";
import ProcessingSteps from "./ProcessingSteps";
import TranscriptEditor from "./TranscriptEditor";

type Mode = "upload" | "url";

const ANON_ID_KEY = "vaani_anon_id";
function getAnonymousId() {
  if (typeof window === "undefined") return "server";
  let id = window.localStorage.getItem(ANON_ID_KEY);
  if (!id) {
    id = uuid();
    window.localStorage.setItem(ANON_ID_KEY, id);
  }
  return id;
}

export default function TranscribeTool() {
  const [mode, setMode] = useState<Mode>("upload");
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [url, setUrl] = useState("");
  const [phase, setPhase] = useState<"uploading" | "processing" | "complete" | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<(TranscriptionResult & { id?: string | null }) | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function validateFile(f: File): string | null {
    const ext = "." + (f.name.split(".").pop() || "").toLowerCase();
    if (!ACCEPTED_EXTENSIONS.includes(ext)) return "Unsupported file format.";
    return null;
  }

  function onPickFile(f: File) {
    const err = validateFile(f);
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setFile(f);
  }

  async function submitFile(f: File) {
    setError(null);
    setResult(null);
    setPhase("uploading");
    setUploadProgress(0);

    const form = new FormData();
    form.append("file", f);
    form.append("anonymousId", getAnonymousId());

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/transcribe");

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        setUploadProgress(Math.round((e.loaded / e.total) * 100));
      }
    };
    xhr.upload.onload = () => setPhase("processing");

    xhr.onload = () => {
      let body: any = {};
      try {
        body = JSON.parse(xhr.responseText);
      } catch {
        //
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        setResult(body);
        setPhase("complete");
      } else {
        setError(body?.message || "Transcription failed. Please try again.");
        setPhase(null);
      }
    };
    xhr.onerror = () => {
      setError("Transcription failed. Please try again.");
      setPhase(null);
    };
    xhr.send(form);
  }

  async function submitUrl() {
    setError(null);
    setResult(null);
    setPhase("processing");
    try {
      const res = await fetch("/api/transcribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const body = await res.json();
      if (!res.ok) {
        setError(body?.message || "Transcription failed. Please try again.");
        setPhase(null);
        return;
      }
      setResult(body);
      setPhase("complete");
    } catch {
      setError("Transcription failed. Please try again.");
      setPhase(null);
    }
  }

  const busy = phase === "uploading" || phase === "processing";

  return (
    <div>
      <div className="rounded-2xl border border-border bg-surface p-2 inline-flex gap-1 mb-4">
        <button
          onClick={() => setMode("upload")}
          className={`px-4 py-2 rounded-xl text-sm ${mode === "upload" ? "bg-surface2 text-white" : "text-muted"}`}
        >
          Upload file
        </button>
        <button
          onClick={() => setMode("url")}
          className={`px-4 py-2 rounded-xl text-sm ${mode === "url" ? "bg-surface2 text-white" : "text-muted"}`}
        >
          Video URL
        </button>
      </div>

      {mode === "upload" ? (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) onPickFile(f);
          }}
          className={`rounded-2xl border-2 border-dashed p-10 text-center transition-colors ${
            dragOver ? "border-accent bg-surface2" : "border-border bg-surface"
          }`}
        >
          <p className="text-lg font-display mb-1">Drag & drop your file here</p>
          <p className="text-muted text-sm mb-4">MP4 · MOV · WEBM · MP3 · WAV · M4A</p>
          <button
            onClick={() => inputRef.current?.click()}
            className="px-5 py-2.5 rounded-lg bg-surface2 border border-border text-sm"
          >
            Browse files
          </button>
          <input
            ref={inputRef}
            type="file"
            accept={ACCEPTED_EXTENSIONS.join(",")}
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onPickFile(f);
            }}
          />
          {file && (
            <div className="mt-6 flex items-center justify-center gap-3">
              <span className="text-sm text-muted truncate max-w-xs">{file.name}</span>
              <button
                disabled={busy}
                onClick={() => submitFile(file)}
                className="px-5 py-2.5 rounded-lg bg-accent text-white text-sm font-medium disabled:opacity-50"
              >
                {busy ? "Working…" : "Transcribe →"}
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-surface p-6">
          <div className="flex gap-2 flex-wrap">
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste video URL (direct .mp4/.mov/.webm/.mp3/.wav/.m4a link)"
              className="flex-1 min-w-[240px] bg-surface2 border border-border rounded-lg px-4 py-3 text-sm"
              disabled={busy}
            />
            <button
              onClick={submitUrl}
              disabled={busy || !url}
              className="px-5 py-3 rounded-lg bg-accent text-white text-sm font-medium disabled:opacity-50"
            >
              {busy ? "Working…" : "Transcribe →"}
            </button>
          </div>
          <p className="text-xs text-muted mt-3">
            Direct links to hosted media files only. Social-platform links (Instagram, YouTube,
            etc.) aren't supported yet — upload the file instead for those.
          </p>
        </div>
      )}

      {error && <p className="text-sm text-red-400 mt-3">{error}</p>}

      <ProcessingSteps phase={phase} uploadProgress={uploadProgress} />

      {result && phase === "complete" && <TranscriptEditor initial={result} />}
    </div>
  );
}
