"use client";

import { useMemo, useState } from "react";
import type { TranscriptSegment, TranscriptionResult } from "@/types";
import { generateSRT, generateVTT, generateTXT } from "@/lib/export/subtitles";
import { TRANSLATION_TARGETS } from "@/lib/config/limits";

type Tab = "original" | "romanized" | "translation";

function download(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function fmt(t: number) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function TranscriptEditor({ initial }: { initial: TranscriptionResult & { id?: string | null } }) {
  const [tab, setTab] = useState<Tab>("original");
  const [original, setOriginal] = useState<TranscriptSegment[]>(initial.segments);
  const [romanized, setRomanized] = useState<TranscriptSegment[] | null>(null);
  const [translation, setTranslation] = useState<TranscriptSegment[] | null>(null);
  const [targetLang, setTargetLang] = useState(TRANSLATION_TARGETS[0]?.code || "en");
  const [loadingRoman, setLoadingRoman] = useState(false);
  const [loadingTranslate, setLoadingTranslate] = useState(false);
  const [query, setQuery] = useState("");
  const [savedNote, setSavedNote] = useState<string | null>(null);

  const active = tab === "original" ? original : tab === "romanized" ? romanized : translation;

  const filteredIndices = useMemo(() => {
    if (!query.trim() || !active) return null;
    const q = query.toLowerCase();
    return new Set(active.map((s, i) => (s.text.toLowerCase().includes(q) ? i : -1)).filter((i) => i >= 0));
  }, [query, active]);

  async function ensureRomanized() {
    if (romanized) return;
    setLoadingRoman(true);
    try {
      const res = await fetch("/api/romanize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ segments: original }),
      });
      const body = await res.json();
      if (res.ok) setRomanized(body.segments);
    } finally {
      setLoadingRoman(false);
    }
  }

  async function ensureTranslation(langCode: string) {
    setLoadingTranslate(true);
    try {
      const langName = TRANSLATION_TARGETS.find((l) => l.code === langCode)?.name || langCode;
      const res = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ segments: original, targetLanguageName: langName }),
      });
      const body = await res.json();
      if (res.ok) setTranslation(body.segments);
    } finally {
      setLoadingTranslate(false);
    }
  }

  function updateSegment(i: number, text: string) {
    if (tab === "original") setOriginal((s) => s.map((seg, idx) => (idx === i ? { ...seg, text } : seg)));
    if (tab === "romanized") setRomanized((s) => (s ? s.map((seg, idx) => (idx === i ? { ...seg, text } : seg)) : s));
    if (tab === "translation") setTranslation((s) => (s ? s.map((seg, idx) => (idx === i ? { ...seg, text } : seg)) : s));
  }

  function handleCopy() {
    if (!active) return;
    navigator.clipboard.writeText(generateTXT(active));
    setSavedNote("Copied to clipboard");
    setTimeout(() => setSavedNote(null), 2000);
  }

  function handleSave() {
    // Local-state save for the anonymous/demo path. Signed-in users' edits are
    // persisted via PATCH to /api/transcriptions/[id] (see README — left as a
    // follow-up route since it's a straightforward extension of this one).
    setSavedNote("Saved");
    setTimeout(() => setSavedNote(null), 2000);
  }

  return (
    <div className="mt-8 rounded-2xl border border-border bg-surface p-6">
      <div className="flex flex-wrap justify-between gap-4 mb-5">
        <div className="flex gap-6 text-sm">
          <div>
            <div className="text-muted text-xs">Detected language</div>
            <div className="font-display text-lg">{initial.languageLabel}</div>
          </div>
          <div>
            <div className="text-muted text-xs">Confidence</div>
            <div className="font-display text-lg">{Math.round(initial.confidence * 100)}%</div>
          </div>
          <div>
            <div className="text-muted text-xs">Duration</div>
            <div className="font-display text-lg">{fmt(initial.durationSeconds)}</div>
          </div>
        </div>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search transcript…"
          className="bg-surface2 border border-border rounded-lg px-3 py-2 text-sm w-56"
        />
      </div>

      <div className="flex gap-2 mb-5 border-b border-border pb-4 flex-wrap items-center">
        <button
          onClick={() => setTab("original")}
          className={`px-4 py-2 rounded-lg text-sm border ${tab === "original" ? "bg-surface2 border-accent" : "border-border text-muted"}`}
        >
          Original
        </button>
        <button
          onClick={() => {
            setTab("romanized");
            ensureRomanized();
          }}
          className={`px-4 py-2 rounded-lg text-sm border ${tab === "romanized" ? "bg-surface2 border-accent" : "border-border text-muted"}`}
        >
          {loadingRoman ? "Romanizing…" : "Romanized"}
        </button>
        <button
          onClick={() => {
            setTab("translation");
            if (!translation) ensureTranslation(targetLang);
          }}
          className={`px-4 py-2 rounded-lg text-sm border ${tab === "translation" ? "bg-surface2 border-accent" : "border-border text-muted"}`}
        >
          {loadingTranslate ? "Translating…" : "Translation"}
        </button>
        {tab === "translation" && (
          <select
            value={targetLang}
            onChange={(e) => {
              setTargetLang(e.target.value);
              setTranslation(null);
              ensureTranslation(e.target.value);
            }}
            className="ml-auto bg-surface2 border border-border rounded-lg px-3 py-2 text-sm"
          >
            {TRANSLATION_TARGETS.map((l) => (
              <option key={l.code} value={l.code}>{l.name}</option>
            ))}
          </select>
        )}
      </div>

      <div className="space-y-4">
        {active ? (
          active.map((seg, i) => (
            <div
              key={seg.id}
              className={`grid grid-cols-[70px_1fr] gap-4 ${
                filteredIndices && !filteredIndices.has(i) ? "opacity-30" : ""
              }`}
            >
              <span className="text-xs text-muted pt-2">
                {fmt(seg.start)}–{fmt(seg.end)}
              </span>
              <textarea
                value={seg.text}
                onChange={(e) => updateSegment(i, e.target.value)}
                rows={2}
                className="w-full bg-surface2 border border-border rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:border-accent"
              />
            </div>
          ))
        ) : (
          <p className="text-muted text-sm">Loading…</p>
        )}
      </div>

      <div className="flex flex-wrap gap-2 mt-6 pt-5 border-t border-border">
        <button onClick={handleSave} className="px-4 py-2 rounded-lg bg-accent text-white text-sm">Save</button>
        <button onClick={handleCopy} className="px-4 py-2 rounded-lg bg-surface2 border border-border text-sm">Copy</button>
        <button
          onClick={() => active && download("transcript.txt", generateTXT(active), "text/plain")}
          className="px-4 py-2 rounded-lg bg-surface2 border border-border text-sm"
        >
          Download TXT
        </button>
        <button
          onClick={() => active && download("transcript.srt", generateSRT(active), "text/plain")}
          className="px-4 py-2 rounded-lg bg-surface2 border border-border text-sm"
        >
          Download SRT
        </button>
        <button
          onClick={() => active && download("transcript.vtt", generateVTT(active), "text/vtt")}
          className="px-4 py-2 rounded-lg bg-surface2 border border-border text-sm"
        >
          Download VTT
        </button>
        {savedNote && <span className="text-xs text-accent2 self-center">{savedNote}</span>}
      </div>
    </div>
  );
}
