"use client";

type Props = {
  phase: "uploading" | "processing" | "complete" | null;
  uploadProgress: number; // 0-100, real XHR progress
};

/**
 * Reflects the two stages we can actually observe from the browser:
 * the real upload progress (from XHR), then a single "processing on the
 * server" state while transcription runs. We deliberately don't fabricate
 * intermediate steps like "Detecting language..." with fake timers — the
 * backend does audio extraction → STT → language detection in one call,
 * so there's nothing granular to report yet. Wiring a job queue with
 * webhook/status polling (see README) would let this show real per-stage
 * progress instead.
 */
export default function ProcessingSteps({ phase, uploadProgress }: Props) {
  if (!phase || phase === "complete") return null;

  return (
    <div className="mt-5 rounded-xl border border-border bg-surface p-5">
      {phase === "uploading" ? (
        <>
          <div className="flex justify-between text-sm mb-2">
            <span>Uploading file…</span>
            <span className="text-muted">{uploadProgress}%</span>
          </div>
          <div className="h-1.5 rounded-full bg-surface2 overflow-hidden">
            <div
              className="h-full bg-accent transition-all duration-200"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        </>
      ) : (
        <div className="flex items-center gap-3 text-sm">
          <span className="h-2 w-2 rounded-full bg-accent animate-pulse" />
          <span>
            Processing audio, detecting language and transcribing speech — this can take a
            moment for longer files.
          </span>
        </div>
      )}
    </div>
  );
}
