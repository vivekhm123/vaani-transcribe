import type { TranscriptSegment } from "@/types";

function pad(n: number, width = 2): string {
  return n.toString().padStart(width, "0");
}

/** seconds -> "HH:MM:SS,mmm" (SRT) */
function srtTimestamp(totalSeconds: number): string {
  const ms = Math.round((totalSeconds % 1) * 1000);
  const s = Math.floor(totalSeconds) % 60;
  const m = Math.floor(totalSeconds / 60) % 60;
  const h = Math.floor(totalSeconds / 3600);
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms, 3)}`;
}

/** seconds -> "HH:MM:SS.mmm" (VTT) */
function vttTimestamp(totalSeconds: number): string {
  return srtTimestamp(totalSeconds).replace(",", ".");
}

/** Real SRT generation from real segment timestamps — not a renamed TXT file. */
export function generateSRT(segments: TranscriptSegment[]): string {
  return segments
    .map((seg, i) => {
      return `${i + 1}\n${srtTimestamp(seg.start)} --> ${srtTimestamp(seg.end)}\n${seg.text}\n`;
    })
    .join("\n");
}

export function generateVTT(segments: TranscriptSegment[]): string {
  const body = segments
    .map((seg) => `${vttTimestamp(seg.start)} --> ${vttTimestamp(seg.end)}\n${seg.text}\n`)
    .join("\n");
  return `WEBVTT\n\n${body}`;
}

export function generateTXT(segments: TranscriptSegment[]): string {
  return segments.map((s) => s.text).join("\n\n");
}
