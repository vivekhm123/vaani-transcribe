/**
 * Single source of truth for every configurable limit in the app.
 * Nothing else in the codebase should hard-code a number that belongs here —
 * change values via environment variables (see .env.example), not by editing
 * call sites.
 */

function num(name: string, fallback: number): number {
  const v = process.env[name];
  if (!v) return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

export const LIMITS = {
  free: {
    maxDurationSeconds: num("FREE_MAX_DURATION_SECONDS", 300), // 5 min
    monthlyTranscriptions: num("FREE_MONTHLY_LIMIT", 3),
  },
  paid: {
    maxDurationSeconds: num("PAID_MAX_DURATION_SECONDS", 3600), // 60 min
    monthlyTranscriptions: num("PAID_MONTHLY_LIMIT", 100),
  },
  anonymous: {
    maxDurationSeconds: num("ANONYMOUS_MAX_DURATION_SECONDS", 60),
    monthlyTranscriptions: num("ANONYMOUS_MONTHLY_LIMIT", 1),
  },
  maxUploadBytes: num("MAX_UPLOAD_BYTES", 200 * 1024 * 1024), // 200MB
} as const;

export const ACCEPTED_MIME_TYPES = [
  "video/mp4",
  "video/quicktime", // .mov
  "video/webm",
  "audio/mpeg", // .mp3
  "audio/wav",
  "audio/x-wav",
  "audio/mp4", // .m4a
  "audio/x-m4a",
] as const;

export const ACCEPTED_EXTENSIONS = [".mp4", ".mov", ".webm", ".mp3", ".wav", ".m4a"];

export const DEMO_MODE = process.env.DEMO_MODE === "true";

export type SupportedLanguage = {
  code: string;
  name: string;
  native: string;
};

/**
 * Central language list. Add/remove a language here only — every selector,
 * translation target list and SEO page in the app reads from this array.
 */
export const SUPPORTED_LANGUAGES: SupportedLanguage[] = [
  { code: "en", name: "English", native: "English" },
  { code: "hi", name: "Hindi", native: "हिंदी" },
  { code: "kn", name: "Kannada", native: "ಕನ್ನಡ" },
  { code: "ta", name: "Tamil", native: "தமிழ்" },
  { code: "te", name: "Telugu", native: "తెలుగు" },
  { code: "ml", name: "Malayalam", native: "മലയാളം" },
  { code: "mr", name: "Marathi", native: "मराठी" },
  { code: "bn", name: "Bengali", native: "বাংলা" },
  { code: "gu", name: "Gujarati", native: "ગુજરાતી" },
  { code: "pa", name: "Punjabi", native: "ਪੰਜਾਬੀ" },
  { code: "or", name: "Odia", native: "ଓଡ଼ିଆ" },
  { code: "as", name: "Assamese", native: "অসমীয়া" },
  { code: "ur", name: "Urdu", native: "اردو" },
];

export const TRANSLATION_TARGETS = SUPPORTED_LANGUAGES.filter((l) =>
  ["en", "hi", "kn", "ta", "te", "ml", "mr", "bn", "gu", "pa"].includes(l.code)
);
