import { ApiError } from "@/types";
import { LIMITS } from "@/lib/config/limits";
import { createSupabaseServiceClient } from "@/lib/supabase/server";

function currentBillingPeriod(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/**
 * Enforces per-user monthly limits and per-file duration limits, and — on
 * success — records the usage. Throws ApiError("LIMIT_REACHED") or
 * ApiError("FILE_TOO_LARGE"-equivalent duration) before any paid API call is made,
 * so a request that will be rejected never reaches the transcription provider.
 *
 * `plan` is a placeholder until billing is wired up (see README) — everyone is
 * "free" today. Swap the lookup below for a real subscription check later.
 */
export async function enforceUsageLimits(params: {
  userId: string | null;
  anonymousId: string | null;
  estimatedDurationSeconds: number;
}) {
  const { userId, anonymousId, estimatedDurationSeconds } = params;
  const tier = userId ? LIMITS.free : LIMITS.anonymous; // TODO: read real plan for userId

  if (estimatedDurationSeconds > tier.maxDurationSeconds) {
    throw new ApiError(
      "FILE_TOO_LARGE",
      `This file is longer than the ${Math.round(tier.maxDurationSeconds / 60)}-minute limit for your plan.`,
      413
    );
  }

  const supabase = createSupabaseServiceClient();
  const period = currentBillingPeriod();
  const key = userId || `anon:${anonymousId}`;

  const { data: existing } = await supabase
    .from("usage")
    .select("*")
    .eq("user_id", userId ?? "00000000-0000-0000-0000-000000000000")
    .eq("billing_period", period)
    .maybeSingle();

  const usedSoFar = existing?.transcription_count ?? 0;
  if (usedSoFar >= tier.monthlyTranscriptions) {
    throw new ApiError(
      "LIMIT_REACHED",
      "You've used all your transcriptions for this month. Upgrade your plan for a higher limit.",
      429
    );
  }

  return {
    async recordUsage(actualDurationSeconds: number) {
      if (!userId) return; // anonymous usage isn't persisted server-side beyond rate limiting today
      await supabase.from("usage").upsert(
        {
          user_id: userId,
          billing_period: period,
          transcription_count: usedSoFar + 1,
          total_audio_seconds: (existing?.total_audio_seconds ?? 0) + actualDurationSeconds,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "user_id,billing_period" }
      );
    },
  };
}
