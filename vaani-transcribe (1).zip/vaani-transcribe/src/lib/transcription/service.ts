import OpenAI from "openai";
import { ApiError, type TranscriptSegment, type TranscriptionResult } from "@/types";
import { DEMO_MODE } from "@/lib/config/limits";
import { transcribeWithOpenAI } from "./providers/openai";
import { transcribeWithMock } from "./providers/mock";
import { generateSRT, generateVTT, generateTXT } from "@/lib/export/subtitles";

/**
 * The one place the rest of the app talks to for anything transcription-related.
 * Swapping speech-to-text or translation vendors means editing the two provider
 * calls below — nothing in the API routes or UI needs to change.
 */
export const transcriptionService = {
  async transcribeAudio(file: File | Blob, filename: string): Promise<TranscriptionResult> {
    const hasKey = !!process.env.TRANSCRIPTION_API_KEY;

    if (!hasKey) {
      if (DEMO_MODE) {
        return transcribeWithMock();
      }
      throw new ApiError(
        "PROVIDER_NOT_CONFIGURED",
        "Transcription API is not configured. Add TRANSCRIPTION_API_KEY to your environment variables.",
        500
      );
    }

    const provider = process.env.TRANSCRIPTION_PROVIDER || "openai";
    switch (provider) {
      case "openai":
        return transcribeWithOpenAI(file, filename);
      default:
        throw new ApiError("PROVIDER_NOT_CONFIGURED", `Unknown TRANSCRIPTION_PROVIDER "${provider}".`, 500);
    }
  },

  /** Language is detected as part of transcribeAudio() above (Whisper returns it
   *  alongside the transcript) rather than as a separate pass — a second call
   *  would just re-run the same audio through the model. Exposed here so the
   *  API surface matches the spec even though it's a thin pass-through. */
  detectLanguage(result: TranscriptionResult) {
    return { language: result.language, languageLabel: result.languageLabel, confidence: result.confidence };
  },

  async translateTranscript(
    segments: TranscriptSegment[],
    targetLanguageName: string
  ): Promise<TranscriptSegment[]> {
    const apiKey = process.env.LLM_API_KEY || process.env.TRANSCRIPTION_API_KEY;
    if (!apiKey) {
      throw new ApiError("PROVIDER_NOT_CONFIGURED", "Translation API is not configured.", 500);
    }
    const client = new OpenAI({ apiKey });

    const prompt = [
      `Translate each numbered line into ${targetLanguageName}.`,
      `Keep the numbering exactly as given. Preserve meaning and tone; this is spoken,`,
      `informal creator content, not a formal document. Reply with ONLY the numbered`,
      `translated lines, nothing else.`,
      "",
      ...segments.map((s, i) => `${i + 1}. ${s.text}`),
    ].join("\n");

    const completion = await client.chat.completions.create({
      model: process.env.LLM_MODEL || "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2,
    });

    const text = completion.choices[0]?.message?.content || "";
    const lines = text
      .split("\n")
      .map((l) => l.replace(/^\s*\d+\.\s*/, "").trim())
      .filter(Boolean);

    return segments.map((seg, i) => ({ ...seg, text: lines[i] || seg.text }));
  },

  async romanizeTranscript(segments: TranscriptSegment[]): Promise<TranscriptSegment[]> {
    const apiKey = process.env.LLM_API_KEY || process.env.TRANSCRIPTION_API_KEY;
    if (!apiKey) {
      throw new ApiError("PROVIDER_NOT_CONFIGURED", "Romanization API is not configured.", 500);
    }
    const client = new OpenAI({ apiKey });

    const prompt = [
      `Transliterate each numbered line into casual Roman/Latin spelling the way an`,
      `Indian creator would type it in a comment section (not strict academic`,
      `transliteration with diacritics) — e.g. "ನೀವು ಕಷ್ಟಪಟ್ಟು" -> "neevu kashtapattu".`,
      `Keep numbering exactly as given, keep any English words as-is, reply with ONLY`,
      `the numbered lines.`,
      "",
      ...segments.map((s, i) => `${i + 1}. ${s.text}`),
    ].join("\n");

    const completion = await client.chat.completions.create({
      model: process.env.LLM_MODEL || "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2,
    });

    const text = completion.choices[0]?.message?.content || "";
    const lines = text
      .split("\n")
      .map((l) => l.replace(/^\s*\d+\.\s*/, "").trim())
      .filter(Boolean);

    return segments.map((seg, i) => ({ ...seg, text: lines[i] || seg.text }));
  },

  generateSubtitles(segments: TranscriptSegment[], format: "srt" | "vtt" | "txt"): string {
    if (format === "srt") return generateSRT(segments);
    if (format === "vtt") return generateVTT(segments);
    return generateTXT(segments);
  },
};
