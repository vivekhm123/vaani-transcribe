import type { TranscriptionResult } from "@/types";

/**
 * Only ever used when DEMO_MODE=true. This is NOT wired into any code path
 * that runs unless that flag is explicitly set — see transcriptionService.ts.
 * Never used in production regardless of DEMO_MODE, see that same file.
 */
export async function transcribeWithMock(): Promise<TranscriptionResult> {
  await new Promise((r) => setTimeout(r, 1200));
  return {
    language: "kn",
    languageLabel: "Kannada",
    confidence: 0.94,
    durationSeconds: 26,
    segments: [
      { id: "seg_0", start: 0, end: 5, text: "ನಮಸ್ಕಾರ ಎಲ್ಲರಿಗೂ, ಇವತ್ತು ಒಂದು ಮುಖ್ಯವಾದ ವಿಷಯದ ಬಗ್ಗೆ ಮಾತಾಡೋಣ." },
      { id: "seg_1", start: 5, end: 12, text: "ನೀವು ಕಷ್ಟಪಟ್ಟು ಕೆಲಸ ಮಾಡಿದರೆ ಮಾತ್ರ ರಿಸಲ್ಟ್ ಸಿಗುತ್ತೆ." },
      { id: "seg_2", start: 12, end: 19, text: "ಪ್ರೋಟೀನ್ ಇಂಟೇಕ್ ಸರಿಯಾಗಿ ಇಟ್ಟುಕೊಳ್ಳಿ, ಅದೇ ಮೊದಲನೇ ಸ್ಟೆಪ್." },
      { id: "seg_3", start: 19, end: 26, text: "ಕಮೆಂಟ್‌ನಲ್ಲಿ ನಿಮ್ಮ ಡೌಟ್ಸ್ ಕೇಳಿ." },
    ],
  };
}
