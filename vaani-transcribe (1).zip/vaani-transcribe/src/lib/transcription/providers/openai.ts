import OpenAI from "openai";
import { ApiError, type TranscriptionResult, type TranscriptSegment } from "@/types";
import { SUPPORTED_LANGUAGES } from "@/lib/config/limits";

/**
 * Real speech-to-text provider backed by an OpenAI-compatible
 * /audio/transcriptions endpoint (Whisper / gpt-4o-transcribe).
 *
 * Swap this file for a different vendor (Sarvam AI, AssemblyAI, Google STT…)
 * without touching any calling code — everything talks to `transcriptionService`,
 * not to this provider directly.
 */
export async function transcribeWithOpenAI(
  file: File | Blob,
  filename: string
): Promise<TranscriptionResult> {
  const apiKey = process.env.TRANSCRIPTION_API_KEY;
  if (!apiKey) {
    throw new ApiError(
      "PROVIDER_NOT_CONFIGURED",
      "Transcription API is not configured. Add TRANSCRIPTION_API_KEY to your environment variables.",
      500
    );
  }

  const client = new OpenAI({ apiKey });
  const model = process.env.TRANSCRIPTION_MODEL || "whisper-1";

  let response;
  try {
    response = await client.audio.transcriptions.create({
      // The SDK accepts a File/Blob directly when running on the server (Node 18+/Next.js route handlers).
      file: new File([file], filename),
      model,
      response_format: "verbose_json",
      // Omitting `language` lets the model auto-detect it — required for mixed-language
      // and code-switched speech, since forcing a language would coerce output into it.
      timestamp_granularities: ["segment"],
    });
  } catch (err: any) {
    if (err?.status === 400 && /language/i.test(err?.message || "")) {
      throw new ApiError("UNSUPPORTED_LANGUAGE", "This language is not currently supported.", 400);
    }
    throw new ApiError("PROVIDER_FAILURE", "Transcription failed. Please try again.", 502);
  }

  const raw = response as unknown as {
    text: string;
    language?: string;
    duration?: number;
    segments?: { start: number; end: number; text: string; avg_logprob?: number }[];
  };

  if (!raw.text || raw.text.trim().length === 0) {
    throw new ApiError("NO_SPEECH_DETECTED", "We couldn't detect clear speech in this recording.", 422);
  }

  const segments: TranscriptSegment[] = (raw.segments || []).map((s, i) => ({
    id: `seg_${i}`,
    start: s.start,
    end: s.end,
    text: s.text.trim(),
  }));

  // Whisper reports language as a lowercase English name ("kannada") or ISO code
  // depending on model/version — normalise against our supported list either way.
  const reported = (raw.language || "").toLowerCase();
  const match =
    SUPPORTED_LANGUAGES.find((l) => l.code === reported) ||
    SUPPORTED_LANGUAGES.find((l) => l.name.toLowerCase() === reported);

  // avg_logprob is a rough per-segment confidence signal; convert to a 0-1 estimate.
  const avgLogProbs = (raw.segments || []).map((s) => s.avg_logprob ?? -0.2);
  const meanLogProb = avgLogProbs.length
    ? avgLogProbs.reduce((a, b) => a + b, 0) / avgLogProbs.length
    : -0.2;
  const confidence = Math.max(0, Math.min(1, 1 + meanLogProb));

  return {
    language: match?.code || reported || "unknown",
    languageLabel: match?.name || raw.language || "Unknown",
    confidence: Number(confidence.toFixed(2)),
    durationSeconds: raw.duration || (segments.at(-1)?.end ?? 0),
    segments: segments.length ? segments : [{ id: "seg_0", start: 0, end: raw.duration || 0, text: raw.text.trim() }],
  };
}
